#include <iostream>
using namespace std;

template <class Type>
class List
{
protected:
    Type* arr;
    int maxSize;
    int currentSize;

public:

    List(int size = 10, int current = 0)
    {
        maxSize = size;
        currentSize = current;
        arr = new Type[maxSize];
    }

    List(const List& obj)
    {
        maxSize = obj.maxSize;
        currentSize = obj.currentSize;

        arr = new Type[maxSize];

        for (int i = 0; i < currentSize; i++)
        {
            arr[i] = obj.arr[i];
        }
    }

    virtual void addElementAtFirstIndex(Type) = 0;

    virtual void addElementAtLastIndex(Type) = 0;

    virtual Type removeElementFromEnd() = 0;

    virtual void removeElementFromStart() = 0;

    virtual ~List()
    {
        delete[] arr;
    }
};
