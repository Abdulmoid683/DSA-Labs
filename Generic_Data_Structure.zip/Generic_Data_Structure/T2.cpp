#include <iostream>
using namespace std;

template <class Type>
class List
{
protected:
    Type* arr;
    int maxSize;
    int currentSize;

public:

    List(int size = 10, int current = 0)
    {
        maxSize = size;
        currentSize = current;
        arr = new Type[maxSize];
    }

    List(const List& obj)
    {
        maxSize = obj.maxSize;
        currentSize = obj.currentSize;

        arr = new Type[maxSize];

        for (int i = 0; i < currentSize; i++)
        {
            arr[i] = obj.arr[i];
        }
    }

    virtual void addElementAtFirstIndex(Type) = 0;
    virtual void addElementAtLastIndex(Type) = 0;
    virtual Type removeElementFromEnd() = 0;
    virtual void removeElementFromStart() = 0;

    virtual ~List()
    {
        delete[] arr;
    }
};

template <class Type>
class MyList : public List<Type>
{
public:

    MyList(int size = 10) : List<Type>(size){}

    MyList(const MyList& obj) : List<Type>(obj){}

    bool empty()
    {
        return this->currentSize == 0;
    }

    bool full()
    {
        return this->currentSize == this->maxSize;
    }

    int size()
    {
        return this->currentSize;
    }

    void addElementAtFirstIndex(Type value)
    {
        if (full())
        {
            cout << "List is full!" << endl;
            return;
        }

        for (int i = this->currentSize; i > 0; i--)
        {
            this->arr[i] = this->arr[i - 1];
        }

        this->arr[0] = value;
        this->currentSize++;
    }

    void addElementAtLastIndex(Type value)
    {
        if (full())
        {
            cout << "List is full!" << endl;
            return;
        }

        this->arr[this->currentSize] = value;
        this->currentSize++;
    }

    Type removeElementFromEnd()
    {
        if (empty())
        {
            cout << "List is empty!" << endl;
            return Type();
        }

        Type value = this->arr[this->currentSize - 1];
        this->currentSize--;

        return value;
    }

    void removeElementFromStart()
    {
        if (empty())
        {
            cout << "List is empty!" << endl;
            return;
        }

        for (int i = 0; i < this->currentSize - 1; i++)
        {
            this->arr[i] = this->arr[i + 1];
        }

        this->currentSize--;
    }

    bool insertAt(int index, Type value)
    {
        if (full() || index < 0 || index > this->currentSize)
        {
            return false;
        }

        for (int i = this->currentSize; i > index; i--)
        {
            this->arr[i] = this->arr[i - 1];
        }

        this->arr[index] = value;
        this->currentSize++;

        return true;
    }

    Type last()
    {
        if (empty())
        {
            cout << "List is empty!" << endl;
            return Type();
        }

        return this->arr[this->currentSize - 1];
    }

    bool search(Type value)
    {
        for (int i = 0; i < this->currentSize; i++)
        {
            if (this->arr[i] == value)
            {
                return true;
            }
        }

        return false;
    }

    void display()
    {
        if (empty())
        {
            cout << "List is empty!" << endl;
            return;
        }

        cout << "List elements: ";

        for (int i = 0; i < this->currentSize; i++)
        {
            cout << this->arr[i] << " ";
        }

        cout << endl;
    }

    ~MyList()
    {
    }
};


int main1(){

    MyList<int> list(10);

    int choice, value, index;

    do
    {
        cout << " MY LIST MENU " << endl;
        cout << "1. Add Element At First" << endl;
        cout << "2. Add Element At Last" << endl;
        cout << "3. Remove Element From End" << endl;
        cout << "4. Remove Element From Start" << endl;
        cout << "5. Check Empty" << endl;
        cout << "6. Check Full" << endl;
        cout << "7. Display Size" << endl;
        cout << "8. Insert At Index" << endl;
        cout << "9. Display Last Element" << endl;
        cout << "10. Search Element" << endl;
        cout << "11. Display List" << endl;
        cout << "0. Exit" << endl;

        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter value: ";
            cin >> value;

            list.addElementAtFirstIndex(value);
            break;

        case 2:
            cout << "Enter value: ";
            cin >> value;

            list.addElementAtLastIndex(value);
            break;

        case 3:
            cout << "Removed element: "
                << list.removeElementFromEnd() << endl;
            break;

        case 4:
            list.removeElementFromStart();
            cout << "First element removed." << endl;
            break;

        case 5:
            if (list.empty())
                cout << "List is empty." << endl;
            else
                cout << "List is not empty." << endl;
            break;

        case 6:
            if (list.full())
                cout << "List is full." << endl;
            else
                cout << "List is not full." << endl;
            break;

        case 7:
            cout << "Current size: " << list.size() << endl;
            break;

        case 8:
            cout << "Enter index: ";
            cin >> index;

            cout << "Enter value: ";
            cin >> value;

            if (list.insertAt(index, value))
                cout << "Element inserted successfully." << endl;
            else
                cout << "Invalid index or list is full." << endl;
            break;

        case 9:
            cout << "Last element: " << list.last() << endl;
            break;

        case 10:
            cout << "Enter value to search: ";
            cin >> value;

            if (list.search(value))
                cout << "Element found!" << endl;
            else
                cout << "Element not found!" << endl;
            break;

        case 11:
            list.display();
            break;

        case 0:
            cout << "Program ended." << endl;
            break;

        default:
            cout << "Invalid choice!" << endl;
        }

    } while (choice != 0);

    return 0;
}
