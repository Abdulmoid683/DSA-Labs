#include <iostream>
using namespace std;
template <class Type>
class List
{
protected:
    Type* arr;
    int maxSize;
    int currentSize;

public:

    List(int size = 10, int current = 0)
    {
        maxSize = size;
        currentSize = current;
        arr = new Type[maxSize];
    }

    List(const List& obj)
    {
        maxSize = obj.maxSize;
        currentSize = obj.currentSize;

        arr = new Type[maxSize];

        for (int i = 0; i < currentSize; i++)
        {
            arr[i] = obj.arr[i];
        }
    }

    virtual void addElementAtFirstIndex(Type) = 0;
    virtual void addElementAtLastIndex(Type) = 0;
    virtual Type removeElementFromEnd() = 0;
    virtual void removeElementFromStart() = 0;

    virtual ~List()
    {
        delete[] arr;
    }
};

template <class Type>
class MyList : public List<Type>
{
public:

    MyList(int size = 10) : List<Type>(size)
    {
    }

    MyList(const MyList& obj) : List<Type>(obj)
    {
    }

    bool empty()
    {
        return this->currentSize == 0;
    }

    bool full()
    {
        return this->currentSize == this->maxSize;
    }

    int size()
    {
        return this->currentSize;
    }

    void addElementAtFirstIndex(Type value)
    {
        if (full())
            return;

        for (int i = this->currentSize; i > 0; i--)
        {
            this->arr[i] = this->arr[i - 1];
        }

        this->arr[0] = value;
        this->currentSize++;
    }

    void addElementAtLastIndex(Type value)
    {
        if (full())
            return;

        this->arr[this->currentSize] = value;
        this->currentSize++;
    }

    Type removeElementFromEnd()
    {
        if (empty())
            return Type();

        Type value = this->arr[this->currentSize - 1];
        this->currentSize--;

        return value;
    }

    void removeElementFromStart()
    {
        if (empty())
            return;

        for (int i = 0; i < this->currentSize - 1; i++)
        {
            this->arr[i] = this->arr[i + 1];
        }

        this->currentSize--;
    }

    bool insertAt(int index, Type value)
    {
        if (full() || index < 0 || index > this->currentSize)
            return false;

        for (int i = this->currentSize; i > index; i--)
        {
            this->arr[i] = this->arr[i - 1];
        }

        this->arr[index] = value;
        this->currentSize++;

        return true;
    }

    Type last()
    {
        if (empty())
            return Type();

        return this->arr[this->currentSize - 1];
    }

    bool search(Type value)
    {
        for (int i = 0; i < this->currentSize; i++)
        {
            if (this->arr[i] == value)
                return true;
        }

        return false;
    }

    void display()
    {
        if (empty())
        {
            cout << "List is empty!" << endl;
            return;
        }

        for (int i = 0; i < this->currentSize; i++)
        {
            cout << this->arr[i] << " ";
        }

        cout << endl;
    }

    ~MyList(){ }
};

template <class Type>
class CustomList : public MyList<Type>
{
public:

    CustomList(int size = 10) : MyList<Type>(size)
    {
    }
    CustomList(const CustomList& obj) : MyList<Type>(obj){ }

    bool isPrime(Type num)
    {
        if (num < 2)
            return false;

        for (int i = 2; i * i <= num; i++)
        {
            if (num % i == 0)
                return false;
        }

        return true;
    }

    Type sum_ofPrime()
    {
        Type sum = 0;

        for (int i = 0; i < this->currentSize; i++)
        {
            if (isPrime(this->arr[i]))
            {
                sum += this->arr[i];
            }
        }

        return sum;
    }

    // Second maximum even number
    Type secondMaxEven()
    {
        Type max1 = Type();
        Type max2 = Type();

        bool found1 = false;
        bool found2 = false;

        for (int i = 0; i < this->currentSize; i++)
        {
            Type value = this->arr[i];

            if (value % 2 == 0)
            {
                if (!found1 || value > max1)
                {
                    if (found1)
                    {
                        max2 = max1;
                        found2 = true;
                    }

                    max1 = value;
                    found1 = true;
                }
                else if (value < max1 &&
                    (!found2 || value > max2))
                {
                    max2 = value;
                    found2 = true;
                }
            }
        }

        if (!found2)
        {
            cout << "Second maximum even number does not exist!" << endl;
            return Type();
        }

        return max2;
    }

    Type secondMinOdd()
    {
        Type min1 = Type();
        Type min2 = Type();

        bool found1 = false;
        bool found2 = false;

        for (int i = 0; i < this->currentSize; i++)
        {
            Type value = this->arr[i];

            if (value % 2 != 0)
            {
                if (!found1 || value < min1)
                {
                    if (found1)
                    {
                        min2 = min1;
                        found2 = true;
                    }

                    min1 = value;
                    found1 = true;
                }
                else if (value > min1 &&
                    (!found2 || value < min2))
                {
                    min2 = value;
                    found2 = true;
                }
            }
        }

        if (!found2)
        {
            cout << "Second minimum odd number does not exist!" << endl;
            return Type();
        }

        return min2;
    }

    void printDuplicates()
    {
        bool found = false;

        for (int i = 0; i < this->currentSize; i++)
        {
            bool alreadyPrinted = false;

            for (int k = 0; k < i; k++)
            {
                if (this->arr[i] == this->arr[k])
                {
                    alreadyPrinted = true;
                    break;
                }
            }

            if (alreadyPrinted)
                continue;

            int count = 0;

            for (int j = 0; j < this->currentSize; j++)
            {
                if (this->arr[i] == this->arr[j])
                {
                    count++;
                }
            }

            if (count > 1)
            {
                cout << this->arr[i] << " ";
                found = true;
            }
        }

        if (!found)
            cout << "No duplicates found!";

        cout << endl;
    }
    void rotateRight(int start, int end, int r)
    {
        int len = end - start + 1;

        if (len <= 1)
            return;

        r = r % len;

        for (int k = 0; k < r; k++)
        {
            Type temp = this->arr[end];

            for (int i = end; i > start; i--)
            {
                this->arr[i] = this->arr[i - 1];
            }

            this->arr[start] = temp;
        }
    }
    void rotateLeft(int start, int end, int r)
    {
        int len = end - start + 1;

        if (len <= 1)
            return;

        r = r % len;

        for (int k = 0; k < r; k++)
        {
            Type temp = this->arr[start];

            for (int i = start; i < end; i++)
            {
                this->arr[i] = this->arr[i + 1];
            }

            this->arr[end] = temp;
        }
    }
    void rotateClockwaise(int r){
        if (this->currentSize == 0)
            return;

        int mid = this->currentSize / 2;

        rotateRight(0, mid - 1, r);
        rotateRight(mid, this->currentSize - 1, r);
    }
    void rotateanitclockwaise(int rt){
        if (this->currentSize == 0)
            return;

        int mid = this->currentSize / 2;

        rotateLeft(0, mid - 1, rt);
        rotateLeft(mid, this->currentSize - 1, rt);
    }

    ~CustomList(){ }
};

int main(){
    CustomList<int> list(20);

    int choice, value, r;

    do
    {
        cout << " CUSTOM LIST MENU " << endl;
        cout << "1. Add Element At First" << endl;
        cout << "2. Add Element At Last" << endl;
        cout << "3. Display List" << endl;
        cout << "4. Sum Of Prime Numbers" << endl;
        cout << "5. Second Maximum Even Number" << endl;
        cout << "6. Second Minimum Odd Number" << endl;
        cout << "7. Print Duplicates" << endl;
        cout << "8. Rotate Clockwise" << endl;
        cout << "9. Rotate Anti-Clockwise" << endl;
        cout << "0. Exit" << endl;

        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "Enter value: ";
            cin >> value;
            list.addElementAtFirstIndex(value);
            break;

        case 2:
            cout << "Enter value: ";
            cin >> value;
            list.addElementAtLastIndex(value);
            break;

        case 3:
            cout << "List: ";
            list.display();
            break;

        case 4:
            cout << "Sum of prime numbers: " << list.sum_ofPrime() << endl;
            break;

        case 5:
            cout << "Second maximum even number: " << list.secondMaxEven() << endl;
            break;

        case 6:
            cout << "Second minimum odd number: " << list.secondMinOdd() << endl;
            break;

        case 7:
            cout << "Duplicate numbers: ";
            list.printDuplicates();
            break;

        case 8:
            cout << "Enter rotation times: ";
            cin >> r;

            list.rotateClockwaise(r);

            cout << "After clockwise rotation: ";
            list.display();
            break;

        case 9:
            cout << "Enter rotation times: ";
            cin >> r;

            list.rotateanitclockwaise(r);

            cout << "After anti-clockwise rotation: ";
            list.display();
            break;

        case 0:
            cout << "Program ended!" << endl;
            break;

        default:
            cout << "Invalid choice!" << endl;
        }

    } while (choice != 0);

    return 0;
}
